const express = require("express");
const http = require("http");
const crypto = require("crypto");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const rooms = new Map();
const socketRooms = new Map();
const TURN_MS = 30000;

app.disable("x-powered-by");
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ status: "ok", rooms: rooms.size }));

const suits = ["Denari", "Coppe", "Spade", "Bastoni"];
const suitSymbols = { Denari: "🪙", Coppe: "🏆", Spade: "⚔️", Bastoni: "🪵" };

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
function makeDeck() {
  const deck = [];
  for (const suit of suits) {
    for (let value = 1; value <= 10; value++) {
      deck.push({ id: `${suit}-${value}`, suit, value, label: `${value} ${suit}`, symbol: suitSymbols[suit] });
    }
  }
  return shuffle(deck);
}
function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out;
  do {
    out = Array.from({ length: 6 }, () => chars[crypto.randomInt(chars.length)]).join("");
  } while (rooms.has(out));
  return out;
}
function publicCard(c) {
  return { id: c.id, suit: c.suit, value: c.value, label: c.label, symbol: c.symbol };
}
function stateFor(room, playerId) {
  const me = room.players.find(p => p.id === playerId);
  const opponent = room.players.find(p => p.id !== playerId);
  return {
    code: room.code, mode: room.mode, status: room.status,
    players: room.players.map(p => ({ id: p.id, name: p.name, connected: !!p.socketId })),
    playerId, hand: me ? me.hand.map(publicCard) : [],
    table: room.table.map(publicCard),
    piles: room.players.map(p => ({ id: p.id, name: p.name, count: p.pile.length, top: p.pile.length ? publicCard(p.pile[p.pile.length - 1]) : null })),
    scores: room.players.map(p => ({ id: p.id, name: p.name, score: p.score, scope: p.scopeCount, cards: p.pile.length })),
    currentPlayerId: room.currentPlayerId, deckCount: room.deck.length,
    lastMove: room.lastMove, winner: room.winner || null,
    opponentHandCount: opponent ? opponent.hand.length : 0,
    deadline: room.deadline || null
  };
}
function broadcast(room, event, extra = {}) {
  for (const p of room.players) {
    if (p.socketId) io.to(p.socketId).emit(event, { ...stateFor(room, p.id), ...extra });
  }
}
function emitError(socket, message) {
  socket.emit("game:error", { message });
}
function stopTimer(room) {
  if (room.timer) clearTimeout(room.timer);
  room.timer = null;
}
function setTurnTimer(room) {
  stopTimer(room);
  if (room.status !== "playing") return;
  room.deadline = Date.now() + TURN_MS;
  room.timer = setTimeout(() => {
    if (room.status !== "playing") return;
    room.lastMove = "Tempo scaduto: turno passato automaticamente.";
    room.currentPlayerId = room.players.find(p => p.id !== room.currentPlayerId)?.id;
    setTurnTimer(room);
    broadcast(room, "game:state");
  }, TURN_MS);
}
function startGame(room) {
  room.deck = makeDeck();
  room.table = room.deck.splice(0, 4);
  room.players.forEach(p => { p.hand = []; p.pile = []; p.scopeCount = 0; p.score = 0; });
  deal(room);
  room.currentPlayerId = room.players[0].id;
  room.status = "playing";
  room.lastMove = "Partita iniziata!";
  setTurnTimer(room);
  broadcast(room, "game:state");
}
function deal(room) {
  for (const p of room.players) {
    while (p.hand.length < 3 && room.deck.length) p.hand.push(room.deck.pop());
  }
}
function combinationsForSum(cards, target) {
  const matches = [];
  const n = cards.length;
  for (let mask = 1; mask < (1 << n); mask++) {
    let sum = 0; const picked = [];
    for (let i = 0; i < n; i++) if (mask & (1 << i)) { sum += cards[i].value; picked.push(cards[i]); }
    if (sum === target) matches.push(picked);
  }
  return matches;
}
function calculateFinalScores(room) {
  const ps = room.players;
  for (const p of ps) p.score = p.scopeCount;
  for (const p of ps) {
    const cards = p.pile;
    if (cards.length > 20) p.score++;
    if (cards.filter(c => c.suit === "Denari").length > 5) p.score++;
    if (cards.some(c => c.suit === "Denari" && c.value === 7)) p.score++;
    const primieraValues = cards.reduce((acc, c) => {
      const weights = { 7: 21, 6: 18, 1: 16, 5: 15, 4: 14, 3: 13, 2: 12, 8: 10, 9: 10, 10: 10 };
      acc[c.suit] = Math.max(acc[c.suit] || 0, weights[c.value]);
      return acc;
    }, {});
    if (suits.every(s => primieraValues[s])) p.primiera = suits.reduce((sum, s) => sum + primieraValues[s], 0);
    else p.primiera = 0;
  }
  if (ps[0].primiera > ps[1].primiera) ps[0].score++;
  else if (ps[1].primiera > ps[0].primiera) ps[1].score++;
}
function finishGame(room) {
  stopTimer(room);
  // Le carte rimaste sul tavolo vanno all'ultimo giocatore che ha effettuato una presa.
  if (room.table.length && room.lastCapturerId) {
    const capturer = room.players.find(p => p.id === room.lastCapturerId);
    if (capturer) capturer.pile.push(...room.table);
    room.table = [];
  }
  if (room.mode === "scopa") calculateFinalScores(room);
  else room.players.forEach(p => { p.score = p.pile.length; });
  room.status = "finished";
  const [a, b] = room.players;
  room.winner = a.score === b.score ? "pareggio" : (a.score > b.score ? a.id : b.id);
  room.lastMove = "Partita terminata!";
  broadcast(room, "game:state");
}
function maybeDealOrFinish(room) {
  if (room.players.every(p => p.hand.length === 0)) {
    if (room.deck.length) deal(room);
    else { finishGame(room); return; }
  }
  setTurnTimer(room);
  broadcast(room, "game:state");
}
function playCard(room, player, cardId, selectedIds) {
  if (room.status !== "playing") throw new Error("La partita non è in corso.");
  if (room.currentPlayerId !== player.id) throw new Error("Non è il tuo turno.");
  const cardIndex = player.hand.findIndex(c => c.id === cardId);
  if (cardIndex < 0) throw new Error("Carta non valida.");
  const card = player.hand[cardIndex];
  const selected = Array.isArray(selectedIds) ? selectedIds : [];
  const selectedCards = selected.map(id => room.table.find(c => c.id === id));
  if (selectedCards.some(c => !c) || new Set(selected).size !== selected.length) throw new Error("Selezione delle carte non valida.");

  // Ruba Mazzetto: prima prova a rubare il mazzetto avversario se la carta
  // giocata ha lo stesso valore della carta in cima al suo mazzetto.
  if (room.mode === "ruba") {
    const opponent = room.players.find(p => p.id !== player.id);
    const top = opponent.pile[opponent.pile.length - 1];
    if (top && top.value === card.value) {
      player.hand.splice(cardIndex, 1);
      player.pile.push(...opponent.pile, card);
      opponent.pile = [];
      room.lastCapturerId = player.id;
      room.lastMove = `Furto mazzetto di ${opponent.name}!`;
      room.currentPlayerId = opponent.id;
      maybeDealOrFinish(room);
      return;
    }
    // Se corrisponde al proprio mazzetto, raccoglie le carte nel proprio.
    const ownTop = player.pile[player.pile.length - 1];
    if (ownTop && ownTop.value === card.value) {
      player.hand.splice(cardIndex, 1);
      player.pile.push(card);
      room.lastMove = `${player.name} ha consolidato il proprio mazzetto.`;
      room.currentPlayerId = opponent.id;
      maybeDealOrFinish(room);
      return;
    }
  }

  let captured = [];
  if (selectedCards.length) {
    const sum = selectedCards.reduce((total, c) => total + c.value, 0);
    if (sum !== card.value) throw new Error("Le carte selezionate devono avere una somma uguale alla carta giocata.");
    captured = selectedCards;
  } else {
    const equal = room.table.filter(c => c.value === card.value);
    if (equal.length) {
      if (equal.length > 1) throw new Error("Seleziona quale carta uguale vuoi prendere.");
      captured = equal;
    } else {
      const sums = combinationsForSum(room.table, card.value);
      if (sums.length) throw new Error("Puoi prendere carte che sommano al valore giocato: selezionale sul tavolo.");
    }
  }

  player.hand.splice(cardIndex, 1);
  if (captured.length) {
    const ids = new Set(captured.map(c => c.id));
    room.table = room.table.filter(c => !ids.has(c.id));
    player.pile.push(card, ...captured);
    room.lastCapturerId = player.id;
    let message = `${player.name} ha preso ${captured.length} carta/e.`;
    if (room.mode === "scopa" && room.table.length === 0 && (player.hand.length > 0 || room.deck.length > 0)) {
      player.scopeCount++;
      message += " SCOPA!";
    }
    room.lastMove = message;
  } else {
    room.table.push(card);
    room.lastMove = `${player.name} ha lasciato una carta sul tavolo.`;
  }
  const opponent = room.players.find(p => p.id !== player.id);
  room.currentPlayerId = opponent.id;
  maybeDealOrFinish(room);
}

io.on("connection", socket => {
  socket.emit("server:ready", { message: "Connesso al server." });

  socket.on("room:create", payload => {
    if (socketRooms.has(socket.id)) return emitError(socket, "Sei già in una stanza.");
    const roomCode = code();
    const player = { id: crypto.randomUUID(), socketId: socket.id, name: cleanName(payload?.name), hand: [], pile: [], scopeCount: 0, score: 0 };
    const room = { code: roomCode, mode: payload?.mode === "ruba" ? "ruba" : "scopa", status: "waiting", players: [player], deck: [], table: [], currentPlayerId: null, lastMove: "In attesa del secondo giocatore.", winner: null, lastCapturerId: null, timer: null };
    rooms.set(roomCode, room);
    socketRooms.set(socket.id, roomCode);
    socket.join(roomCode);
    socket.emit("room:joined", { code: roomCode, playerId: player.id, shareUrl: `${baseUrl(socket)}/?room=${roomCode}` });
    broadcast(room, "room:state");
  });

  socket.on("room:join", payload => {
    if (socketRooms.has(socket.id)) return emitError(socket, "Sei già in una stanza.");
    const roomCode = String(payload?.code || "").trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!room) return emitError(socket, "Stanza non trovata.");
    if (room.players.length >= 2 || room.status !== "waiting") return emitError(socket, "La stanza è piena.");
    const player = { id: crypto.randomUUID(), socketId: socket.id, name: cleanName(payload?.name), hand: [], pile: [], scopeCount: 0, score: 0 };
    room.players.push(player);
    socketRooms.set(socket.id, roomCode);
    socket.join(roomCode);
    socket.emit("room:joined", { code: roomCode, playerId: player.id, shareUrl: `${baseUrl(socket)}/?room=${roomCode}` });
    startGame(room);
  });

  socket.on("game:play", payload => {
    const roomCode = socketRooms.get(socket.id);
    const room = roomCode && rooms.get(roomCode);
    if (!room) return emitError(socket, "Non sei in una stanza.");
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player) return emitError(socket, "Giocatore non trovato.");
    try { playCard(room, player, payload?.cardId, payload?.tableCardIds); }
    catch (e) { emitError(socket, e.message); }
  });

  socket.on("disconnect", () => {
    const roomCode = socketRooms.get(socket.id);
    socketRooms.delete(socket.id);
    if (!roomCode) return;
    const room = rooms.get(roomCode);
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (player) {
      room.status = "waiting";
      stopTimer(room);
      io.to(roomCode).emit("room:state", { ...stateFor(room, player.id), disconnected: player.name });
      // Mantiene la stanza in memoria per 30 secondi; la partita viene chiusa
      // se il giocatore non rientra (la riconnessione sarà aggiunta in una versione successiva).
      setTimeout(() => {
        if (rooms.get(roomCode) === room && room.players.some(p => p.id === player.id && !p.socketId)) {
          rooms.delete(roomCode);
          io.to(roomCode).emit("room:closed", { reason: "disconnessione" });
        }
      }, 30000).unref?.();
      player.socketId = null;
    }
  });
});

function cleanName(value) {
  if (typeof value !== "string") return "Giocatore";
  return value.trim().replace(/\s+/g, " ").slice(0, 20) || "Giocatore";
}
function baseUrl(socket) {
  if (process.env.PUBLIC_BASE_URL) return process.env.PUBLIC_BASE_URL.replace(/\/+$/, "");
  const host = socket.handshake.headers.host || "localhost:3000";
  const proto = socket.handshake.headers["x-forwarded-proto"] || "https";
  return `${String(proto).split(",")[0]}://${host}`;
}

server.listen(PORT, "0.0.0.0", () => console.log(`Server in ascolto sulla porta ${PORT}`));
